import logo from './logo.svg';
// import './App.css';
import AboutUs from './components/AboutUs';
// import Middle from  './components/Middle';
import Value from './components/Value';
import Last from './components/Last';

function App() {
  return (
    <div className="App">
     <AboutUs/>
     <Value/>
     <Last/>
     {/* <Middle/> */}
    </div>
  );
}

export default App;
